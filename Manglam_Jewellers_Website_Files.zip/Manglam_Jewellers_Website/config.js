// Paste your deployed Google Apps Script Web App URL between the quotes.
// Example: const MANGLAM_CONFIG = { API_URL: "https://script.google.com/macros/s/...../exec" };
window.MANGLAM_CONFIG = { API_URL: "" };
